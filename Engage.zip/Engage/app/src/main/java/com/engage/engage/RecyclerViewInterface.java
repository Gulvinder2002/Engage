package com.engage.engage;

public interface RecyclerViewInterface {
    void onItemClick(int position,String name,String link);
}
